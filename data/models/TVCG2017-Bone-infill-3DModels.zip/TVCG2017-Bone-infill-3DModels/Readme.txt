Enclosed are three optimized, bone-like infill models. Please refer to the following article for a detailed explanation of the optimization algorithm. 

Jun Wu, Niels Aage, R�diger Westermann, and Ole Sigmund, "Infill Optimization for Additive Manufacturing -- Approaching Bone-like Porous Structures", IEEE Transactions on Visualization and Computer Graphics, doi:10.1109/TVCG.2017.2655523, January 2017 

Feb. 2, 2017, Jun Wu (email: j.wu-1@tudelft.nl)
